from selenium.webdriver.common.by import By

class dashboardPage:
    def __init__(self,driver,menuItem):
        # self.driver=driver
        self.menuItem=(By.LINK_TEXT,menuItem)


    def entermenu(self,driver):
        driver.find_element(self.menuItem).click()



