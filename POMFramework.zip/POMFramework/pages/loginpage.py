from selenium import webdriver
import time
from selenium.webdriver.common.by import By

from POMFramework.libraries.orangeHRMMethods import enterLoginDetails


class LoginPage:
    def  __init__(self,browser,appurl,username,password):
        self.browser=browser
        self.appurl=appurl
        self.username=username
        self.password=password

    def loginOrangehrm(self):
        if self.browser=="chrome":
            driver=webdriver.Chrome()
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login")
        driver.maximize_window()
        time.sleep(5)
        enterLoginDetails(driver,self.username,self.password)
        time.sleep(5)
        pageTitle = driver.find_element(By.XPATH, "//h6[text()='Dashboard']").text
        assert pageTitle == "Dashboard", "Not Dashboard"
        time.sleep(3)
        return driver



