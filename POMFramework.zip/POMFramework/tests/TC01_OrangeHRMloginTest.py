from POMFramework.pages.dashboardPage import dashboardPage
from POMFramework.pages.loginpage import LoginPage

login_page=LoginPage("chrome","https://opensource-demo.orangehrmlive.com/web/index.php/auth/login","Admin","admin123")
driver=login_page.loginOrangehrm()
# # dashboardPage.menu()
dashboard_page=dashboardPage("Leave")
dashboard_page.entermenu(driver)